
  # Create Stripe Pricing Page

  This is a code bundle for Create Stripe Pricing Page. The original project is available at https://www.figma.com/design/Q0Vfoi4AhC6rfL6rnj8GIa/Create-Stripe-Pricing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  